# Step 1: This creates a list of workers dynamically (at least 400)
set.seed(123)

first_names_male <- c("John", "Mike", "David", "Chris", "James")
first_names_female <- c("Disere", "Doti", "Deri", "Grace", "Charity")
last_names <- c("Prosper", "Comfort", "Kevin", "Precious", "Richard")

workers <- data.frame(
  id = 1:400,
  name = character(400),
  gender = character(400),
  salary = numeric(400),
  stringsAsFactors = FALSE
)

for (i in 1:400) {
  gender <- sample(c("Male", "Female"), 1)
  if (gender == "Male") {
    name <- paste(sample(first_names_male, 1), sample(last_names, 1))
  } else {
    name <- paste(sample(first_names_female, 1), sample(last_names, 1))
  }
  salary <- sample(5000:35000, 1)
  
  workers[i, ] <- list(i, name, gender, salary)
}

# Step 2: Generating of payment slips
for (i in 1:nrow(workers)) {
  level <- "N/A"
  
  # Step 3: Apply conditional statements
  if (workers$salary[i] > 10000 && workers$salary[i] < 20000) {
    level <- "A1"
  }
  if (workers$salary[i] > 7500 && workers$salary[i] < 30000 && workers$gender[i] == "Female") {
    level <- "A5-F"
  }
  
  # Step 4: Print payment slip
  cat("Payment Slip - ID:", workers$id[i], "\n")
  cat("Name:", workers$name[i], "\n")
  cat("Gender:", workers$gender[i], "\n")
  cat("Salary: $", workers$salary[i], "\n", sep = "")
  cat("Employee Level:", level, "\n")
  cat(strrep("-", 40), "\n")
}
