import random

# Step 1: Dynamically create a list of workers (at least 400 workers)
# Each worker will have: ID, Name, Gender, Salary
try:
    workers = []
    first_names_male = ["John", "Mike", "David", "Chris", "James"]
    first_names_female = ["Disere", "Doti", "Deri", "Grace", "Charity"]
    last_names = ["Prosper", "Comfort", "Kevin", "Precious", "Richard"]

    for i in range(400):
        gender = random.choice(["Male", "Female"])
        if gender == "Male":
            name = f"{random.choice(first_names_male)} {random.choice(last_names)}"
        else:
            name = f"{random.choice(first_names_female)} {random.choice(last_names)}"

        salary = random.randint(5000, 35000)  # salary between 5k and 35k
        workers.append({"id": i + 1, "name": name, "gender": gender, "salary": salary})

    # Step 2: Generate payment slips using for loop
    for worker in workers:
        level = "N/A"

        # Step 3: Apply conditional statements
        if 10000 < worker["salary"] < 20000:
            level = "A1"
        if 7500 < worker["salary"] < 30000 and worker["gender"] == "Female":
            level = "A5-F"

        # Step 4: Print payment slip
        print(f"Payment Slip - ID: {worker['id']}")
        print(f"Name: {worker['name']}")
        print(f"Gender: {worker['gender']}")
        print(f"Salary: ${worker['salary']}")
        print(f"Employee Level: {level}")
        print("-" * 40)

except Exception as e:
    print(f"An error occurred: {e}")